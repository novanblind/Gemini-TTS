# Gemini TTS by Novan (aplikasi Android)

Versi aplikasi mandiri dari skrip Jieshuo "Gemini tts by novan v8".

## Fitur
- Mode satu suara dan multi suara (2 pembicara, naskah `Suara1: ...` / `Suara2: ...`)
- 40 karakter suara + tombol putar contoh suara (offline, dari `assets/voice_cache`)
- 38 logat/bahasa daerah dan 50 gaya/emosi suara
- Pilihan format: **MP3 (bawaan)**, M4A (AAC), WAV, OGG (Opus, Android 10+)
- Hasil disimpan ke folder **Music** bawaan sistem HP (tanpa membuat folder baru)
- 5 model TTS, otomatis pindah ke model berikutnya bila kuota habis (atau pilih satu model):
  `gemini-2.5-flash-preview-tts`, `gemini-2.5-pro-preview-tts`, `gemini-3.1-flash-tts-preview`,
  `gemini-3.8-flash-tts`, `gemini-3.8-flash-lite-tts`
- Berjalan sebagai layanan latar depan, jadi tetap jalan saat aplikasi ditutup/layar mati
- Dialog hasil: Bagikan, Putar, Hapus, Tutup

## Membangun lewat GitHub Actions
1. Unggah seluruh isi folder ini ke repo GitHub (cabang `main`).
2. Buka tab **Actions** > **Build APK** > **Run workflow** (atau cukup push).
3. Setelah selesai, unduh artefak **GeminiTTS-APK** (berisi `app-release.apk`).

## Tanda tangan APK (repo publik)
Kunci tanda tangan tidak disimpan di repo. Buat sekali di komputer/Termux:

    keytool -genkeypair -keystore release.jks -alias gtts -keyalg RSA -keysize 2048 -validity 36500
    base64 -w0 release.jks

Lalu di GitHub: **Settings > Secrets and variables > Actions** tambahkan
`KEYSTORE_BASE64` (hasil base64), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (misal `gtts`), `KEY_PASSWORD`.
Simpan `release.jks` baik-baik di luar repo. Tanpa secrets, build tetap jalan memakai kunci debug,
tetapi tanda tangannya berganti-ganti sehingga APK baru tidak bisa menimpa yang lama (harus uninstall dulu).

## Catatan
- Encoder MP3 memakai library `com.github.NorthernCaptain:TAndroidLame:1.1` dari JitPack.
