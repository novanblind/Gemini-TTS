package com.novan.geminitts;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Menyimpan hasil ke folder Musik bawaan sistem HP (MediaStore).
 * Tidak membuat folder sendiri.
 */
public final class AudioSaver {
    private AudioSaver() {}

    public static final class Saved {
        public Uri uri;
        public String displayName;
        public String mime;
        public String location;
    }

    public static Saved save(Context ctx, File encoded, String baseName, int format) throws IOException {
        String ext = Catalog.FORMAT_EXT[format];
        String mime = Catalog.FORMAT_MIME[format];
        String fileName = baseName + "." + ext;
        ContentResolver cr = ctx.getContentResolver();
        Saved s = new Saved();
        s.mime = mime;
        s.location = Environment.DIRECTORY_MUSIC + "/" + fileName;

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            Uri uri = cr.insert(collection, v);
            if (uri == null) throw new IOException("Gagal membuat berkas di folder Musik.");
            try {
                OutputStream os = cr.openOutputStream(uri);
                if (os == null) throw new IOException("Gagal membuka berkas tujuan.");
                InputStream in = new FileInputStream(encoded);
                try {
                    AudioEncoder.copy(in, os);
                } finally {
                    try { in.close(); } catch (IOException ignored) { }
                    os.close();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(uri, done, null, null);
            } catch (IOException e) {
                try { cr.delete(uri, null, null); } catch (Exception ignored) { }
                throw e;
            }
            s.uri = uri;
            Cursor c = null;
            try {
                c = cr.query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
                if (c != null && c.moveToFirst()) fileName = c.getString(0);
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            s.displayName = fileName;
            s.location = Environment.DIRECTORY_MUSIC + "/" + fileName;
            return s;
        }

        // Android 9 ke bawah: tulis ke folder Music bawaan lalu daftarkan ke MediaStore
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Folder Musik tidak dapat diakses.");
        File target = new File(dir, fileName);
        int n = 1;
        while (target.exists()) {
            fileName = baseName + " (" + n + ")." + ext;
            target = new File(dir, fileName);
            n++;
        }
        InputStream in = new FileInputStream(encoded);
        OutputStream os = new FileOutputStream(target);
        try {
            AudioEncoder.copy(in, os);
        } finally {
            try { in.close(); } catch (IOException ignored) { }
            os.close();
        }
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.DATA, target.getAbsolutePath());
        v.put(MediaStore.MediaColumns.TITLE, baseName);
        Uri uri = cr.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
        MediaScannerConnection.scanFile(ctx, new String[]{target.getAbsolutePath()}, new String[]{mime}, null);
        if (uri == null) throw new IOException("Gagal mendaftarkan berkas ke penyimpanan.");
        s.uri = uri;
        s.displayName = fileName;
        s.location = Environment.DIRECTORY_MUSIC + "/" + fileName;
        return s;
    }
}
