package com.novan.geminitts;

import android.content.Context;
import android.content.SharedPreferences;

/** Penyimpanan pengaturan (kunci API, pilihan terakhir). */
public final class Prefs {
    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences("gemini_tts_config", Context.MODE_PRIVATE);
    }

    public static String cleanKey(CharSequence key) {
        return key == null ? "" : key.toString().replaceAll("\\s+", "");
    }

    public static String getKey(Context c) {
        return get(c).getString("gemini_api_key", "");
    }

    public static void saveKey(Context c, CharSequence key) {
        get(c).edit().putString("gemini_api_key", cleanKey(key)).apply();
    }

    public static void resetKey(Context c) {
        get(c).edit().putString("gemini_api_key", "").apply();
    }
}
