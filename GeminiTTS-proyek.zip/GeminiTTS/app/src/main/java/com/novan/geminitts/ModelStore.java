package com.novan.geminitts;

import android.content.Context;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Daftar model TTS yang tersimpan di HP (bisa diperbarui lewat tombol). */
public final class ModelStore {
    private ModelStore() {}

    private static final String KEY = "tts_model_list";

    public static List<String> load(Context c) {
        List<String> r = new ArrayList<>();
        String s = Prefs.get(c).getString(KEY, null);
        if (s != null) {
            try {
                JSONArray a = new JSONArray(s);
                for (int i = 0; i < a.length(); i++) {
                    String m = a.optString(i, "");
                    if (!m.isEmpty() && !r.contains(m)) r.add(m);
                }
            } catch (Exception ignored) {
            }
        }
        if (r.isEmpty()) r.addAll(Arrays.asList(Catalog.DEFAULT_MODELS));
        return r;
    }

    public static void save(Context c, List<String> models) {
        JSONArray a = new JSONArray();
        for (String m : models) a.put(m);
        Prefs.get(c).edit().putString(KEY, a.toString()).apply();
    }

    /** Isi pilihan di layar: "Otomatis" lalu setiap model. */
    public static List<String> labels(List<String> models) {
        List<String> r = new ArrayList<>();
        r.add("Otomatis (" + models.size() + " model berurutan, pindah jika kuota habis)");
        r.addAll(models);
        return r;
    }
}
