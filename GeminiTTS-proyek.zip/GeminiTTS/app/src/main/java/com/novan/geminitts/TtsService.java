package com.novan.geminitts;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/** Menjaga proses tetap hidup selama audio dibuat di latar belakang. */
public class TtsService extends Service {
    private static final String CHANNEL = "tts_job";
    private static final int NOTIF_PROGRESS = 1;
    private static final int NOTIF_DONE = 2;
    private static boolean workerRunning = false;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        Notification n = build("Membuat audio...", true);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_PROGRESS, n);
        }

        if (!TtsJob.isRunning() || workerRunning) {
            if (!workerRunning) stopSelf();
            return START_NOT_STICKY;
        }
        workerRunning = true;

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        final PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "geminitts:job");
        wl.acquire(60 * 60 * 1000L);

        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    TtsJob.Outcome o = TtsJob.execute(TtsService.this, new TtsJob.Sink() {
                        @Override public void progress(String text) {
                            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                            nm.notify(NOTIF_PROGRESS, build(text, true));
                        }
                    });
                    stopForeground(true);
                    if (!TtsJob.hasListener() && !o.cancelled) {
                        String msg = o.success ? "Audio selesai: " + o.saved.displayName
                                : "Gagal membuat audio. Buka aplikasi untuk melihat penyebabnya.";
                        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                        nm.notify(NOTIF_DONE, build(msg, false));
                    }
                } finally {
                    workerRunning = false;
                    if (wl.isHeld()) wl.release();
                    stopSelf();
                }
            }
        }).start();
        return START_NOT_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Pembuatan audio", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification build(String text, boolean ongoing) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        b.setSmallIcon(ongoing ? android.R.drawable.stat_sys_download : android.R.drawable.stat_sys_download_done)
                .setContentTitle("Gemini TTS by Novan")
                .setContentText(text)
                .setOngoing(ongoing)
                .setAutoCancel(!ongoing)
                .setContentIntent(pi);
        return b.build();
    }
}
