package com.novan.geminitts;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pemecah naskah (port dari fungsi Lua splitTextIntoChunks / parseMultiScript / splitMultiChunks). */
public final class TextUtil {
    private TextUtil() {}

    private static final Pattern SENTENCE = Pattern.compile("[^.!?]+[.!?]*");

    public static final class Item {
        public final String speaker;
        public final String text;
        Item(String s, String t) { speaker = s; text = t; }
    }

    private static List<String> lines(String text) {
        List<String> r = new ArrayList<>();
        for (String l : text.split("\\r?\\n")) {
            if (!l.isEmpty()) r.add(l);
        }
        return r;
    }

    /** Mode satu suara. */
    public static List<String> splitSingle(String text, int maxChars) {
        List<String> chunks = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String paragraph : lines(text)) {
            if (paragraph.length() <= maxChars) {
                if (cur.length() + paragraph.length() + 1 <= maxChars) {
                    if (cur.length() > 0) cur.append('\n');
                    cur.append(paragraph);
                } else {
                    if (cur.length() > 0) chunks.add(cur.toString());
                    cur.setLength(0);
                    cur.append(paragraph);
                }
            } else {
                Matcher m = SENTENCE.matcher(paragraph);
                while (m.find()) {
                    String sentence = m.group();
                    if (cur.length() + sentence.length() <= maxChars) {
                        cur.append(sentence);
                    } else {
                        if (cur.length() > 0) chunks.add(cur.toString());
                        cur.setLength(0);
                        cur.append(sentence);
                    }
                }
            }
        }
        if (cur.length() > 0) chunks.add(cur.toString());
        if (chunks.isEmpty()) chunks.add(text);
        return chunks;
    }

    /** Mode multi suara: "Nama: kalimat". Baris tanpa nama = lanjutan pembicara sebelumnya. */
    public static List<Item> parseMulti(String text, String name1, String name2) {
        List<Item> items = new ArrayList<>();
        String l1 = name1.toLowerCase();
        String l2 = name2.toLowerCase();
        String current = name1;
        for (String line : lines(text)) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;
            int colon = trimmed.indexOf(':');
            if (colon > 0) {
                String who = trimmed.substring(0, colon).trim().toLowerCase();
                String rest = trimmed.substring(colon + 1).trim();
                if (who.equals(l1)) {
                    current = name1;
                    trimmed = rest;
                } else if (who.equals(l2)) {
                    current = name2;
                    trimmed = rest;
                }
            }
            if (!trimmed.isEmpty()) items.add(new Item(current, trimmed));
        }
        return items;
    }

    public static List<String> splitMulti(List<Item> items, int maxChars) {
        List<String> chunks = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (Item it : items) {
            String full = it.speaker + ": " + it.text;
            if (full.length() <= maxChars) {
                push(chunks, cur, full, maxChars);
            } else {
                Matcher m = SENTENCE.matcher(it.text);
                while (m.find()) {
                    String s = m.group().trim();
                    if (!s.isEmpty()) push(chunks, cur, it.speaker + ": " + s, maxChars);
                }
            }
        }
        if (cur.length() > 0) chunks.add(cur.toString());
        return chunks;
    }

    private static void push(List<String> chunks, StringBuilder cur, String s, int maxChars) {
        if (cur.length() == 0) {
            cur.append(s);
        } else if (cur.length() + s.length() + 1 <= maxChars) {
            cur.append('\n').append(s);
        } else {
            chunks.add(cur.toString());
            cur.setLength(0);
            cur.append(s);
        }
    }

    public static String cleanSpeakerName(CharSequence raw, String fallback) {
        String n = raw == null ? "" : raw.toString().replaceAll("[:\\s\"\\\\]", "");
        return n.isEmpty() ? fallback : n;
    }

    /** Awalan instruksi logat + gaya (mode satu suara). */
    public static String singlePrefix(int logat, int vibe) {
        String l = Catalog.LOGAT_PROMPTS[logat];
        String v = Catalog.VIBE_PROMPTS[vibe];
        if (!l.isEmpty() && !v.isEmpty()) return "Bacakan teks berikut secara fasih menggunakan " + l + ", dengan " + v + ": ";
        if (!l.isEmpty()) return "Bacakan teks berikut secara fasih menggunakan " + l + ": ";
        if (!v.isEmpty()) return "Bacakan teks berikut dengan " + v + ": ";
        return "";
    }

    /** Awalan instruksi multi suara: logat & gaya berbeda tiap pembicara. */
    public static String multiPrefix(String n1, String n2, int l1, int v1, int l2, int v2) {
        String d1 = describe(l1, v1);
        String d2 = describe(l2, v2);
        if (d1.isEmpty() && d2.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("Bacakan percakapan berikut secara fasih. ");
        if (!d1.isEmpty()) sb.append(n1).append(" berbicara ").append(d1).append(". ");
        if (!d2.isEmpty()) sb.append(n2).append(" berbicara ").append(d2).append(". ");
        sb.append("Percakapan:");
        return sb.toString();
    }

    private static String describe(int l, int v) {
        String lp = Catalog.LOGAT_PROMPTS[l];
        String vp = Catalog.VIBE_PROMPTS[v];
        StringBuilder sb = new StringBuilder();
        if (!lp.isEmpty()) sb.append("menggunakan ").append(lp);
        if (!vp.isEmpty()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append("dengan ").append(vp);
        }
        return sb.toString();
    }
}
