package com.novan.geminitts;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;

import com.naman14.androidlame.AndroidLame;
import com.naman14.androidlame.LameBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Mengubah berkas PCM 16-bit mono menjadi MP3 / M4A / WAV / OGG. */
public final class AudioEncoder {
    private AudioEncoder() {}

    public static final int MP3 = 0;
    public static final int M4A = 1;
    public static final int WAV = 2;
    public static final int OGG = 3;

    public static void encode(File pcm, File out, int format, int rate) throws Exception {
        if (pcm.length() < 2) throw new IOException("Data audio kosong.");
        switch (format) {
            case M4A:
                encodeWithCodec(pcm, out, rate, "audio/mp4a-latm", MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4, 64000);
                break;
            case WAV:
                encodeWav(pcm, out, rate);
                break;
            case OGG:
                if (android.os.Build.VERSION.SDK_INT < 29) {
                    throw new IOException("Format OGG Opus membutuhkan Android 10 ke atas. Pilih MP3, M4A, atau WAV.");
                }
                encodeWithCodec(pcm, out, rate, "audio/opus", 4 /* MUXER_OUTPUT_OGG */, 48000);
                break;
            case MP3:
            default:
                encodeMp3(pcm, out, rate);
                break;
        }
    }

    // ------------------------------------------------------------------ WAV
    private static void encodeWav(File pcm, File out, int rate) throws IOException {
        long dataLen = pcm.length();
        OutputStream os = new FileOutputStream(out);
        InputStream in = new FileInputStream(pcm);
        try {
            ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
            h.put(new byte[]{'R', 'I', 'F', 'F'});
            h.putInt((int) (36 + dataLen));
            h.put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
            h.putInt(16);
            h.putShort((short) 1);          // PCM
            h.putShort((short) 1);          // mono
            h.putInt(rate);
            h.putInt(rate * 2);             // byte rate
            h.putShort((short) 2);          // block align
            h.putShort((short) 16);         // bit per sample
            h.put(new byte[]{'d', 'a', 't', 'a'});
            h.putInt((int) dataLen);
            os.write(h.array());
            copy(in, os);
        } finally {
            try { in.close(); } catch (IOException ignored) { }
            os.close();
        }
    }

    // ------------------------------------------------------------------ MP3
    private static void encodeMp3(File pcm, File out, int rate) throws IOException {
        AndroidLame lame = new LameBuilder()
                .setInSampleRate(rate)
                .setOutChannels(1)
                .setOutBitrate(64)
                .setOutSampleRate(rate)
                .setQuality(5)
                .build();
        InputStream in = new FileInputStream(pcm);
        OutputStream os = new FileOutputStream(out);
        try {
            final int samplesPerRead = 8192;
            byte[] raw = new byte[samplesPerRead * 2];
            short[] samples = new short[samplesPerRead];
            byte[] mp3buf = new byte[(int) (7200 + samplesPerRead * 1.25)];
            int n;
            while ((n = readFully(in, raw)) > 0) {
                int count = n / 2;
                ByteBuffer.wrap(raw, 0, count * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(samples, 0, count);
                int w = lame.encode(samples, samples, count, mp3buf);
                if (w < 0) throw new IOException("Encoder MP3 gagal (kode " + w + ").");
                if (w > 0) os.write(mp3buf, 0, w);
            }
            int f = lame.flush(mp3buf);
            if (f > 0) os.write(mp3buf, 0, f);
        } finally {
            try { lame.close(); } catch (Throwable ignored) { }
            try { in.close(); } catch (IOException ignored) { }
            os.close();
        }
    }

    // ------------------------------------------------------ AAC (M4A) / Opus (OGG)
    private static void encodeWithCodec(File pcm, File out, int rate, String mime, int muxerFormat, int bitrate) throws Exception {
        MediaFormat fmt = MediaFormat.createAudioFormat(mime, rate, 1);
        if ("audio/mp4a-latm".equals(mime)) {
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        }
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);

        MediaCodec codec = MediaCodec.createEncoderByType(mime);
        MediaMuxer muxer = null;
        InputStream in = new FileInputStream(pcm);
        boolean codecStarted = false;
        boolean muxerStarted = false;
        try {
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            codec.start();
            codecStarted = true;
            muxer = new MediaMuxer(out.getAbsolutePath(), muxerFormat);

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            byte[] tmp = new byte[16384];
            long totalBytes = 0;
            boolean inputDone = false;
            int track = -1;
            final long timeoutUs = 10000;

            while (true) {
                if (!inputDone) {
                    int idx = codec.dequeueInputBuffer(timeoutUs);
                    if (idx >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(idx);
                        ib.clear();
                        int want = Math.min(ib.remaining(), tmp.length);
                        want -= want % 2;
                        int n = want > 0 ? in.read(tmp, 0, want) : -1;
                        long pts = (totalBytes / 2) * 1000000L / rate;
                        if (n <= 0) {
                            codec.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            n -= n % 2;
                            ib.put(tmp, 0, n);
                            totalBytes += n;
                            codec.queueInputBuffer(idx, 0, n, pts, 0);
                        }
                    }
                }

                int oi = codec.dequeueOutputBuffer(info, timeoutUs);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!muxerStarted) {
                        track = muxer.addTrack(codec.getOutputFormat());
                        muxer.start();
                        muxerStarted = true;
                    }
                } else if (oi >= 0) {
                    ByteBuffer ob = codec.getOutputBuffer(oi);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (info.size > 0 && muxerStarted && ob != null) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        muxer.writeSampleData(track, ob, info);
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                }
            }
        } finally {
            try { in.close(); } catch (IOException ignored) { }
            if (codecStarted) { try { codec.stop(); } catch (Exception ignored) { } }
            try { codec.release(); } catch (Exception ignored) { }
            if (muxer != null) {
                if (muxerStarted) { try { muxer.stop(); } catch (Exception ignored) { } }
                try { muxer.release(); } catch (Exception ignored) { }
            }
        }
    }

    // ------------------------------------------------------------------ util
    private static int readFully(InputStream in, byte[] buf) throws IOException {
        int total = 0;
        while (total < buf.length) {
            int n = in.read(buf, total, buf.length - total);
            if (n < 0) break;
            total += n;
        }
        return total;
    }

    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
