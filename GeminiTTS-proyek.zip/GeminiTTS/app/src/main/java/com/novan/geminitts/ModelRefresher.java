package com.novan.geminitts;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Mengambil daftar model dari https://generativelanguage.googleapis.com/v1beta/models
 * lalu menyaring hanya model Text-to-Speech.
 */
public final class ModelRefresher {
    private ModelRefresher() {}

    public static final class Result {
        public String error;                       // null bila berhasil
        public List<String> models = new ArrayList<>();
        public List<String> added = new ArrayList<>();
        public List<String> removed = new ArrayList<>();
    }

    public static Result refresh(String apiKey, List<String> current) {
        Result r = new Result();
        List<String> found = new ArrayList<>();
        try {
            String token = null;
            int pages = 0;
            do {
                String u = "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000"
                        + (token == null ? "" : "&pageToken=" + URLEncoder.encode(token, "UTF-8"));
                HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                try {
                    c.setRequestMethod("GET");
                    c.setRequestProperty("x-goog-api-key", apiKey);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(30000);
                    int code = c.getResponseCode();
                    if (code != 200) {
                        String body = "";
                        InputStream es = c.getErrorStream();
                        if (es != null) body = read(es);
                        if (code == 400 || code == 401 || code == 403) {
                            r.error = "Kunci API tidak valid atau tidak punya akses (HTTP " + code + ").";
                        } else {
                            r.error = "Gagal mengambil daftar model (HTTP " + code + ")."
                                    + (body.isEmpty() ? "" : "\n" + body);
                        }
                        return r;
                    }
                    JSONObject root = new JSONObject(read(c.getInputStream()));
                    JSONArray arr = root.optJSONArray("models");
                    if (arr != null) {
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject m = arr.optJSONObject(i);
                            if (m == null) continue;
                            String name = m.optString("name", "");
                            if (name.startsWith("models/")) name = name.substring(7);
                            if (name.isEmpty() || !name.toLowerCase().contains("tts")) continue;
                            JSONArray methods = m.optJSONArray("supportedGenerationMethods");
                            if (methods != null && methods.length() > 0) {
                                boolean gen = false;
                                for (int k = 0; k < methods.length(); k++) {
                                    if ("generateContent".equals(methods.optString(k))) gen = true;
                                }
                                if (!gen) continue;
                            }
                            if (!found.contains(name)) found.add(name);
                        }
                    }
                    token = root.optString("nextPageToken", "");
                    if (token.isEmpty()) token = null;
                } finally {
                    c.disconnect();
                }
            } while (token != null && ++pages < 10);
        } catch (Exception e) {
            r.error = "Gagal terhubung ke Google: " + e;
            return r;
        }

        if (found.isEmpty()) {
            r.error = "Tidak ada model Text-to-Speech di daftar Google, jadi daftar lama dibiarkan.";
            return r;
        }

        // Model lama yang masih aktif tetap di urutannya; model baru ditambah di belakang.
        for (String m : current) if (found.contains(m)) r.models.add(m);
        List<String> fresh = new ArrayList<>();
        for (String m : found) if (!current.contains(m)) fresh.add(m);
        Collections.sort(fresh);
        r.models.addAll(fresh);
        r.added.addAll(fresh);
        for (String m : current) if (!found.contains(m)) r.removed.add(m);
        return r;
    }

    private static String read(InputStream in) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        char[] buf = new char[8192];
        int n;
        while ((n = br.read(buf)) != -1) sb.append(buf, 0, n);
        br.close();
        return sb.toString();
    }
}
