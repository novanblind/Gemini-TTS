package com.novan.geminitts;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements TtsJob.Listener {

    private SharedPrefsHelper ph;

    private LinearLayout root;
    private final List<View> multiViews = new ArrayList<>();

    private Spinner spMode, spSuara, spSuara2, spLogat, spVibe, spLogat2, spVibe2, spFormat, spModel;
    private TextView txtSuara, txtLogat, txtVibe, txtNarasi;
    private EditText editNama1, editNama2, editJudul, editNarasi;
    private Button btnGenerate, btnCancel;
    private TextView statusText;

    private MediaPlayer samplePlayer;
    private MediaPlayer resultPlayer;

    /** Pembantu kecil untuk SharedPreferences. */
    private final class SharedPrefsHelper {
        int getInt(String k, int d) { return Prefs.get(MainActivity.this).getInt(k, d); }
        void putInt(String k, int v) { Prefs.get(MainActivity.this).edit().putInt(k, v).apply(); }
        String getStr(String k, String d) { return Prefs.get(MainActivity.this).getString(k, d); }
    }

    // ================================================================ siklus hidup
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ph = new SharedPrefsHelper();
        setTitle("Gemini TTS by Novan");
        buildUi();
        askPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        TtsJob.setListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        TtsJob.setListener(null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopSample();
        stopResultPlayer();
    }

    private void askPermissions() {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!hasStoragePermission()) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 100);
    }

    private boolean hasStoragePermission() {
        return Build.VERSION.SDK_INT >= 29
                || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    // ================================================================ pembantu UI
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView addLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(16);
        t.setPadding(0, dp(14), 0, dp(2));
        root.addView(t);
        return t;
    }

    private Spinner addSpinner(TextView label, String[] items, int selected) {
        Spinner sp = new Spinner(this);
        sp.setId(View.generateViewId());
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setSingleLine(false);
                t.setEllipsize(null);
                return t;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(position, convertView, parent);
                t.setSingleLine(false);
                t.setEllipsize(null);
                t.setPadding(dp(12), dp(10), dp(12), dp(10));
                return t;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        if (selected >= 0 && selected < items.length) sp.setSelection(selected);
        if (label != null) label.setLabelFor(sp.getId());
        root.addView(sp);
        return sp;
    }

    private Button addButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        root.addView(b);
        return b;
    }

    private EditText addEdit(TextView label, String hint, String value) {
        EditText e = new EditText(this);
        e.setId(View.generateViewId());
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        if (label != null) label.setLabelFor(e.getId());
        root.addView(e);
        return e;
    }

    private void bindPref(Spinner sp, final String key, final Runnable extra) {
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ph.putInt(key, position);
                if (extra != null) extra.run();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        View[] views = {editNarasi, editJudul, editNama1, editNama2};
        for (View v : views) {
            if (v != null && imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            if (v != null) v.clearFocus();
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ================================================================ susunan layar
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(8), dp(16), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        addButton("Pengaturan kunci API Gemini", new View.OnClickListener() {
            @Override public void onClick(View v) { showApiKeyDialog(); }
        });

        TextView lMode = addLabel("Mode Suara:");
        spMode = addSpinner(lMode, Catalog.MODE_LABELS, ph.getInt("last_mode_index", 0));

        txtSuara = addLabel("Karakter Suara Gemini (40 Pilihan):");
        spSuara = addSpinner(txtSuara, Catalog.VOICE_LABELS, ph.getInt("last_voice_index", 0));
        addButton("Putar Suara Terpilih", new View.OnClickListener() {
            @Override public void onClick(View v) { playSample(spSuara.getSelectedItemPosition()); }
        });

        TextView lSuara2 = addLabel("Karakter Suara 2 (40 Pilihan):");
        spSuara2 = addSpinner(lSuara2, Catalog.VOICE_LABELS, ph.getInt("last_voice2_index", 1));
        Button btnPlay2 = addButton("Putar Suara 2 Terpilih", new View.OnClickListener() {
            @Override public void onClick(View v) { playSample(spSuara2.getSelectedItemPosition()); }
        });

        TextView lNama1 = addLabel("Nama Pembicara 1 (label di naskah):");
        editNama1 = addEdit(lNama1, "Suara1", ph.getStr("speaker1_name", "Suara1"));
        TextView lNama2 = addLabel("Nama Pembicara 2 (label di naskah):");
        editNama2 = addEdit(lNama2, "Suara2", ph.getStr("speaker2_name", "Suara2"));

        multiViews.add(lSuara2);
        multiViews.add(spSuara2);
        multiViews.add(btnPlay2);
        multiViews.add(lNama1);
        multiViews.add(editNama1);
        multiViews.add(lNama2);
        multiViews.add(editNama2);

        txtLogat = addLabel("Pilihan Logat Bicara / Bahasa Daerah (38 Pilihan):");
        spLogat = addSpinner(txtLogat, Catalog.LOGAT_LABELS, ph.getInt("last_logat_index", 0));

        txtVibe = addLabel("Gaya / Emosi Suara (50 Pilihan):");
        spVibe = addSpinner(txtVibe, Catalog.VIBE_LABELS, ph.getInt("last_vibe_index", 0));

        TextView lLogat2 = addLabel("Logat Bicara Pembicara 2:");
        spLogat2 = addSpinner(lLogat2, Catalog.LOGAT_LABELS, ph.getInt("last_logat2_index", 0));
        TextView lVibe2 = addLabel("Gaya / Emosi Suara Pembicara 2:");
        spVibe2 = addSpinner(lVibe2, Catalog.VIBE_LABELS, ph.getInt("last_vibe2_index", 0));
        multiViews.add(lLogat2);
        multiViews.add(spLogat2);
        multiViews.add(lVibe2);
        multiViews.add(spVibe2);

        TextView lFormat = addLabel("Format Audio:");
        spFormat = addSpinner(lFormat, Catalog.FORMAT_LABELS, ph.getInt("last_format_index", 0));

        TextView lModel = addLabel("Model Gemini:");
        spModel = addSpinner(lModel, Catalog.modelLabels(), ph.getInt("last_model_index", 0));

        TextView lJudul = addLabel("Judul Audio (Nama File):");
        editJudul = addEdit(lJudul, "Ketik judul file di sini", "");

        txtNarasi = addLabel("Naskah Narasi (Terisi: 0 karakter):");
        editNarasi = new EditText(this);
        editNarasi.setId(View.generateViewId());
        editNarasi.setHint("Tulis teks naskah panjang di sini...");
        editNarasi.setMinLines(5);
        editNarasi.setGravity(Gravity.TOP | Gravity.START);
        editNarasi.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        txtNarasi.setLabelFor(editNarasi.getId());
        editNarasi.addTextChangedListener(new TextWatcher() {
            @Override public void afterTextChanged(Editable s) {
                txtNarasi.setText("Naskah Narasi (Terisi: " + s.length() + " karakter):");
            }
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
        });
        root.addView(editNarasi);

        addButton("TUTUP KEYBOARD", new View.OnClickListener() {
            @Override public void onClick(View v) {
                hideKeyboard();
                toast("Keyboard ditutup.");
            }
        });

        statusText = new TextView(this);
        statusText.setTextSize(16);
        statusText.setPadding(0, dp(14), 0, dp(4));
        statusText.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        statusText.setVisibility(View.GONE);
        root.addView(statusText);

        btnGenerate = addButton("Buat Audio", new View.OnClickListener() {
            @Override public void onClick(View v) { startGenerate(); }
        });
        btnCancel = addButton("Batalkan", new View.OnClickListener() {
            @Override public void onClick(View v) {
                TtsJob.cancel();
                statusText.setText("Membatalkan...");
            }
        });
        btnCancel.setVisibility(View.GONE);

        spMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ph.putInt("last_mode_index", position);
                updateModeUi();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        bindPref(spSuara, "last_voice_index", null);
        bindPref(spSuara2, "last_voice2_index", null);
        bindPref(spLogat, "last_logat_index", null);
        bindPref(spVibe, "last_vibe_index", null);
        bindPref(spLogat2, "last_logat2_index", null);
        bindPref(spVibe2, "last_vibe2_index", null);
        bindPref(spFormat, "last_format_index", null);
        bindPref(spModel, "last_model_index", null);

        updateModeUi();
    }

    private boolean isMulti() {
        return spMode.getSelectedItemPosition() == 1;
    }

    private void updateModeUi() {
        boolean multi = isMulti();
        int vis = multi ? View.VISIBLE : View.GONE;
        for (View v : multiViews) v.setVisibility(vis);
        if (multi) {
            txtSuara.setText("Karakter Suara 1 (40 Pilihan):");
            txtLogat.setText("Logat Bicara Pembicara 1:");
            txtVibe.setText("Gaya / Emosi Suara Pembicara 1:");
            editNarasi.setHint("Tulis percakapan, satu baris per giliran bicara. Contoh:\nSuara1: Halo, apa kabar?\nSuara2: Baik, terima kasih.");
        } else {
            txtSuara.setText("Karakter Suara Gemini (40 Pilihan):");
            txtLogat.setText("Pilihan Logat Bicara / Bahasa Daerah (38 Pilihan):");
            txtVibe.setText("Gaya / Emosi Suara (50 Pilihan):");
            editNarasi.setHint("Tulis teks naskah panjang di sini...");
        }
    }

    private void setBusy(boolean busy) {
        btnGenerate.setEnabled(!busy);
        btnCancel.setVisibility(busy ? View.VISIBLE : View.GONE);
        statusText.setVisibility(busy ? View.VISIBLE : View.GONE);
    }

    // ================================================================ sampel suara
    private void stopSample() {
        try {
            if (samplePlayer != null) {
                try { if (samplePlayer.isPlaying()) samplePlayer.stop(); } catch (Exception ignored) { }
                samplePlayer.release();
            }
        } catch (Exception ignored) {
        }
        samplePlayer = null;
    }

    private void playSample(int voiceIndex) {
        stopSample();
        String name = Catalog.VOICE_KEYS[voiceIndex];
        String path = String.format(Locale.US, "voice_cache/%02d_sample_%s.wav", voiceIndex + 1, name);
        try {
            AssetFileDescriptor afd = getAssets().openFd(path);
            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer m) { stopSample(); }
            });
            mp.prepare();
            mp.start();
            samplePlayer = mp;
        } catch (Exception e) {
            toast("Berkas sampel suara " + name + " tidak dapat diputar.");
        }
    }

    // ================================================================ kunci API
    private void showApiKeyDialog() {
        LinearLayout lay = new LinearLayout(this);
        lay.setOrientation(LinearLayout.VERTICAL);
        lay.setPadding(dp(20), dp(10), dp(20), dp(6));

        TextView info = new TextView(this);
        info.setText("Masukkan API Key dari Google AI Studio.");
        lay.addView(info);

        Button get = new Button(this);
        get.setText("Dapatkan Kunci API (Google AI Studio)");
        get.setAllCaps(false);
        get.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")));
                } catch (Exception e) {
                    toast("Tidak ada aplikasi peramban.");
                }
            }
        });
        lay.addView(get);

        TextView lbl = new TextView(this);
        lbl.setText("Kunci API:");
        lbl.setPadding(0, dp(12), 0, 0);
        lay.addView(lbl);

        final EditText keyEdit = new EditText(this);
        keyEdit.setId(View.generateViewId());
        keyEdit.setHint("AIzaSy...");
        keyEdit.setText(Prefs.getKey(this));
        keyEdit.setSingleLine(true);
        lbl.setLabelFor(keyEdit.getId());
        lay.addView(keyEdit);

        Button reset = new Button(this);
        reset.setText("Hapus Kunci API Tersimpan");
        reset.setAllCaps(false);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Prefs.resetKey(MainActivity.this);
                keyEdit.setText("");
                toast("Kunci API berhasil dihapus.");
            }
        });
        lay.addView(reset);

        ScrollView sv = new ScrollView(this);
        sv.addView(lay);

        new AlertDialog.Builder(this)
                .setTitle("Pengaturan kunci API Gemini")
                .setView(sv)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String key = Prefs.cleanKey(keyEdit.getText());
                        if (key.isEmpty()) {
                            toast("Kunci API tidak boleh kosong.");
                            return;
                        }
                        Prefs.saveKey(MainActivity.this, key);
                        toast("Kunci API berhasil disimpan.");
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // ================================================================ mulai membuat audio
    private void startGenerate() {
        if (TtsJob.isRunning()) return;
        hideKeyboard();

        String key = Prefs.getKey(this);
        if (key.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Pemberitahuan")
                    .setMessage("Kunci API Gemini belum dimasukkan. Silakan klik tombol di bawah untuk memasukkan API Key Anda.")
                    .setPositiveButton("Buka Pengaturan", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { showApiKeyDialog(); }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
            return;
        }

        String naskah = editNarasi.getText().toString();
        if (naskah.trim().isEmpty()) {
            toast("Naskah narasi tidak boleh kosong.");
            return;
        }

        if (!hasStoragePermission()) {
            toast("Izin penyimpanan dibutuhkan untuk menyimpan audio.");
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
            return;
        }

        boolean multi = isMulti();
        String name1 = TextUtil.cleanSpeakerName(editNama1.getText(), "Suara1");
        String name2 = TextUtil.cleanSpeakerName(editNama2.getText(), "Suara2");
        if (name1.equalsIgnoreCase(name2)) {
            name1 = "Suara1";
            name2 = "Suara2";
        }
        Prefs.get(this).edit().putString("speaker1_name", name1).putString("speaker2_name", name2).apply();

        int l1 = spLogat.getSelectedItemPosition();
        int v1 = spVibe.getSelectedItemPosition();
        int l2 = spLogat2.getSelectedItemPosition();
        int v2 = spVibe2.getSelectedItemPosition();

        TtsJob.Params p = new TtsJob.Params();
        p.apiKey = key;
        p.naskah = naskah;
        p.title = editJudul.getText().toString();
        p.multi = multi;
        p.name1 = name1;
        p.name2 = name2;
        p.voice1 = spSuara.getSelectedItemPosition();
        p.voice2 = spSuara2.getSelectedItemPosition();
        p.format = spFormat.getSelectedItemPosition();
        p.modelChoice = spModel.getSelectedItemPosition();
        p.prefix = multi ? TextUtil.multiPrefix(name1, name2, l1, v1, l2, v2) : TextUtil.singlePrefix(l1, v1);

        stopSample();
        TtsJob.begin(p);
        setBusy(true);
        statusText.setText("Membuat audio di latar belakang...");

        Intent svc = new Intent(this, TtsService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
        else startService(svc);
    }

    // ================================================================ laporan dari pekerjaan
    @Override
    public void onProgress(String text) {
        setBusy(true);
        statusText.setText(text);
    }

    @Override
    public void onFinished(TtsJob.Outcome o) {
        setBusy(false);
        if (o.success) {
            showResultDialog(o);
        } else if (o.cancelled) {
            toast(o.message);
        } else if (o.quota) {
            new AlertDialog.Builder(this)
                    .setTitle("Kunci API Mencapai Batas Kuota")
                    .setMessage("Batas kuota harian gratis untuk seluruh model Gemini yang dicoba pada kunci API Anda telah habis.\n\nSilakan ganti dengan Kunci API baru melalui menu Pengaturan Kunci API Gemini.")
                    .setPositiveButton("Buka Pengaturan API", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { showApiKeyDialog(); }
                    })
                    .setNegativeButton("Tutup", null)
                    .show();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Gagal Menghasilkan Suara")
                    .setMessage(o.message)
                    .setPositiveButton("Tutup", null)
                    .show();
        }
    }

    // ================================================================ dialog "Audio Selesai"
    private void stopResultPlayer() {
        try {
            if (resultPlayer != null) {
                try { resultPlayer.stop(); } catch (Exception ignored) { }
                resultPlayer.release();
            }
        } catch (Exception ignored) {
        }
        resultPlayer = null;
    }

    private void showResultDialog(final TtsJob.Outcome o) {
        final AudioSaver.Saved s = o.saved;

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(10), dp(20), dp(6));

        TextView msg = new TextView(this);
        msg.setText("File: " + s.displayName + "\nSuara: " + o.voiceInfo + "\nLokasi: " + s.location);
        msg.setTextSize(16);
        content.addView(msg);

        final AlertDialog[] holder = new AlertDialog[1];

        Button share = resultButton("Bagikan");
        share.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                stopResultPlayer();
                if (holder[0] != null) holder[0].dismiss();
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(s.mime);
                send.putExtra(Intent.EXTRA_STREAM, s.uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, "Bagikan Audio"));
            }
        });
        content.addView(share);

        Button play = resultButton("Putar");
        play.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                stopResultPlayer();
                try {
                    MediaPlayer mp = new MediaPlayer();
                    mp.setDataSource(MainActivity.this, s.uri);
                    mp.prepare();
                    mp.start();
                    resultPlayer = mp;
                } catch (Exception e) {
                    toast("Gagal memutar audio.");
                }
            }
        });
        content.addView(play);

        Button del = resultButton("Hapus");
        del.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Hapus Audio")
                        .setMessage("Hapus file " + s.displayName + " secara permanen?")
                        .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) {
                                stopResultPlayer();
                                boolean deleted = false;
                                try {
                                    deleted = getContentResolver().delete(s.uri, null, null) > 0;
                                } catch (Exception ignored) {
                                }
                                toast(deleted ? "Audio berhasil dihapus." : "Gagal menghapus audio.");
                                if (deleted && holder[0] != null) holder[0].dismiss();
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
            }
        });
        content.addView(del);

        Button close = resultButton("Tutup");
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (holder[0] != null) holder[0].dismiss();
            }
        });
        content.addView(close);

        ScrollView sv = new ScrollView(this);
        sv.addView(content);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Audio Selesai")
                .setView(sv)
                .create();
        dlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) { stopResultPlayer(); }
        });
        holder[0] = dlg;
        dlg.show();
    }

    private Button resultButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }
}
