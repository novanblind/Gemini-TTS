package com.novan.geminitts;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Pekerjaan pembuatan audio. Berjalan di TtsService (latar depan) dan melapor
 * ke layar utama bila sedang terbuka.
 */
public final class TtsJob {
    private TtsJob() {}

    public static final class Params {
        public String apiKey;
        public String naskah;
        public String title;
        public String name1;
        public String name2;
        public String prefix;
        public boolean multi;
        public int voice1;
        public int voice2;
        public int format;
        /** Daftar model yang dipakai berurutan (satu model bila dipilih manual). */
        public String[] models;
    }

    public static final class Outcome {
        public boolean success;
        public boolean quota;
        public boolean cancelled;
        public String message = "";
        public AudioSaver.Saved saved;
        public String voiceInfo = "";
    }

    public interface Listener {
        void onProgress(String text);
        void onFinished(Outcome outcome);
    }

    public interface Sink {
        void progress(String text);
    }

    private static final class QuotaException extends Exception {
        QuotaException(String m) { super(m); }
    }

    private static final class CancelException extends Exception {
    }

    /** Panjang maksimal satu potongan naskah (karakter) per permintaan ke Gemini. */
    public static final int MAX_CHARS = 4000;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static Listener listener;
    private static Outcome pending;
    private static boolean running;
    private static String lastProgress = "";
    private static volatile boolean cancelled;
    private static Params params;

    public static synchronized boolean isRunning() { return running; }

    public static synchronized boolean hasListener() { return listener != null; }

    public static synchronized void begin(Params p) {
        params = p;
        running = true;
        cancelled = false;
        pending = null;
        lastProgress = "Memulai...";
    }

    public static void cancel() { cancelled = true; }

    public static void setListener(Listener l) {
        Outcome toDeliver = null;
        String progress = null;
        synchronized (TtsJob.class) {
            listener = l;
            if (l != null) {
                if (pending != null) {
                    toDeliver = pending;
                    pending = null;
                } else if (running) {
                    progress = lastProgress;
                }
            }
        }
        if (l != null) {
            if (toDeliver != null) l.onFinished(toDeliver);
            else if (progress != null) l.onProgress(progress);
        }
    }

    private static void postProgress(final String text, Sink sink) {
        synchronized (TtsJob.class) { lastProgress = text; }
        if (sink != null) sink.progress(text);
        MAIN.post(new Runnable() {
            @Override public void run() {
                Listener l;
                synchronized (TtsJob.class) { l = listener; }
                if (l != null) l.onProgress(text);
            }
        });
    }

    private static void deliver(final Outcome o) {
        synchronized (TtsJob.class) { running = false; }
        MAIN.post(new Runnable() {
            @Override public void run() {
                Listener l;
                synchronized (TtsJob.class) {
                    l = listener;
                    if (l == null) pending = o;
                }
                if (l != null) l.onFinished(o);
            }
        });
    }

    private static JSONObject voiceConfig(String voiceName) throws Exception {
        return new JSONObject().put("prebuiltVoiceConfig", new JSONObject().put("voiceName", voiceName));
    }

    private static JSONObject buildSpeech(Params p) throws Exception {
        if (p.multi) {
            JSONArray arr = new JSONArray();
            arr.put(new JSONObject().put("speaker", p.name1).put("voiceConfig", voiceConfig(Catalog.VOICE_KEYS[p.voice1])));
            arr.put(new JSONObject().put("speaker", p.name2).put("voiceConfig", voiceConfig(Catalog.VOICE_KEYS[p.voice2])));
            return new JSONObject().put("multiSpeakerVoiceConfig", new JSONObject().put("speakerVoiceConfigs", arr));
        }
        return new JSONObject().put("voiceConfig", voiceConfig(Catalog.VOICE_KEYS[p.voice1]));
    }

    private static String baseName(String title) {
        String t = title == null ? "" : title.trim();
        t = t.replaceAll("[\\\\/:*?\"<>|]", "_").replaceAll("(?i)\\.(mp3|m4a|wav|ogg)$", "").trim();
        if (t.isEmpty()) {
            t = "Gemini_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        }
        return t;
    }

    private static void sleep(long ms) throws CancelException {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (cancelled) throw new CancelException();
            try { Thread.sleep(100); } catch (InterruptedException e) { throw new CancelException(); }
        }
    }

    /** Dijalankan di thread latar (dari TtsService). */
    public static Outcome execute(Context ctx, Sink sink) {
        final Params p;
        synchronized (TtsJob.class) { p = params; }
        Outcome out = new Outcome();
        Context app = ctx.getApplicationContext();
        File cache = app.getCacheDir();
        File pcmFile = null;
        File encFile = null;
        FileOutputStream fos = null;
        try {
            if (p == null) throw new Exception("Tidak ada tugas.");
            File[] old = cache.listFiles();
            if (old != null) {
                for (File f : old) if (f.getName().startsWith("tts_")) f.delete();
            }

            List<String> chunks;
            if (p.multi) {
                List<TextUtil.Item> items = TextUtil.parseMulti(p.naskah, p.name1, p.name2);
                if (items.isEmpty()) throw new Exception("Naskah percakapan kosong.");
                chunks = TextUtil.splitMulti(items, MAX_CHARS);
            } else {
                chunks = TextUtil.splitSingle(p.naskah, MAX_CHARS);
            }
            JSONObject speech = buildSpeech(p);

            long ts = System.currentTimeMillis();
            pcmFile = new File(cache, "tts_" + ts + ".pcm");
            fos = new FileOutputStream(pcmFile);

            String[] models = p.models;
            if (models == null || models.length == 0) models = Catalog.DEFAULT_MODELS;
            boolean[] dead = new boolean[models.length];
            int rate = 0;
            int total = chunks.size();

            for (int i = 0; i < total; i++) {
                if (cancelled) throw new CancelException();
                if (i > 0) sleep(1500);
                postProgress("Membuat audio, bagian " + (i + 1) + " dari " + total + "...", sink);

                String chunk = chunks.get(i);
                String send = p.prefix.isEmpty() ? chunk : p.prefix + (p.multi ? "\n" : "") + chunk;

                boolean ok = false;
                int tried = 0;
                int quotaCount = 0;
                String lastMsg = "";

                for (int m = 0; m < models.length && !ok; m++) {
                    if (dead[m]) continue;
                    tried++;
                    String model = models[m];
                    for (int attempt = 1; attempt <= 3; attempt++) {
                        if (cancelled) throw new CancelException();
                        if (attempt > 1) sleep(2500);
                        GeminiClient.Result r = GeminiClient.request(p.apiKey, model, send, speech);
                        if (r.status == GeminiClient.OK) {
                            fos.write(r.pcm);
                            if (rate == 0) rate = r.sampleRate;
                            ok = true;
                            break;
                        }
                        lastMsg = r.message;
                        if (r.status == GeminiClient.QUOTA) {
                            quotaCount++;
                            break;
                        }
                        if (r.status == GeminiClient.BAD_KEY) {
                            throw new Exception("Kunci API tidak valid. " + r.message);
                        }
                        if (r.status == GeminiClient.SKIP) {
                            dead[m] = true;
                            break;
                        }
                        // RETRY: ulangi
                    }
                }

                if (!ok) {
                    if (tried > 0 && quotaCount == tried) throw new QuotaException(lastMsg);
                    throw new Exception(lastMsg.isEmpty()
                            ? "Gagal pada bagian ke-" + (i + 1) + " dari " + total
                            : lastMsg);
                }
            }

            fos.flush();
            fos.close();
            fos = null;

            String ext = Catalog.FORMAT_EXT[p.format];
            postProgress("Mengubah ke format " + ext.toUpperCase(Locale.US) + "...", sink);
            encFile = new File(cache, "tts_out_" + ts + "." + ext);
            AudioEncoder.encode(pcmFile, encFile, p.format, rate == 0 ? 24000 : rate);

            postProgress("Menyimpan ke folder Musik...", sink);
            out.saved = AudioSaver.save(app, encFile, baseName(p.title), p.format);
            out.voiceInfo = p.multi
                    ? p.name1 + ": " + Catalog.VOICE_KEYS[p.voice1] + ", " + p.name2 + ": " + Catalog.VOICE_KEYS[p.voice2]
                    : Catalog.VOICE_KEYS[p.voice1];
            out.success = true;
        } catch (CancelException e) {
            out.cancelled = true;
            out.message = "Pembuatan audio dibatalkan.";
        } catch (QuotaException e) {
            out.quota = true;
            out.message = e.getMessage();
        } catch (Throwable e) {
            out.message = e.getMessage() != null ? e.getMessage() : String.valueOf(e);
        } finally {
            if (fos != null) { try { fos.close(); } catch (Exception ignored) { } }
            if (pcmFile != null) pcmFile.delete();
            if (encFile != null) encFile.delete();
        }
        deliver(out);
        return out;
    }
}
