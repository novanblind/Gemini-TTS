package com.novan.geminitts;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Satu permintaan TTS ke Gemini (generateContent). */
public final class GeminiClient {
    private GeminiClient() {}

    public static final int OK = 0;
    /** HTTP 429: kuota model habis. */
    public static final int QUOTA = 1;
    /** Kunci API tidak valid. */
    public static final int BAD_KEY = 2;
    /** Model/permintaan tidak didukung: lewati model ini. */
    public static final int SKIP = 3;
    /** Galat sementara (jaringan, 5xx, respons kosong): boleh diulang. */
    public static final int RETRY = 4;

    public static final class Result {
        public int status = RETRY;
        public String message = "";
        public byte[] pcm;
        public int sampleRate = 24000;
    }

    private static final Pattern RATE = Pattern.compile("rate=(\\d+)");

    public static Result request(String apiKey, String model, String text, JSONObject speechConfig) {
        Result r = new Result();
        HttpURLConnection conn = null;
        try {
            JSONObject part = new JSONObject().put("text", text);
            JSONObject content = new JSONObject().put("parts", new JSONArray().put(part));
            JSONObject gen = new JSONObject()
                    .put("responseModalities", new JSONArray().put("AUDIO"))
                    .put("speechConfig", speechConfig);
            JSONObject body = new JSONObject()
                    .put("contents", new JSONArray().put(content))
                    .put("generationConfig", gen);

            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("x-goog-api-key", apiKey);
            conn.setDoOutput(true);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(90000);

            byte[] payload = body.toString().getBytes("UTF-8");
            OutputStream os = conn.getOutputStream();
            os.write(payload);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            if (code == 200) {
                String resp = read(conn.getInputStream());
                parse(resp, model, r);
            } else if (code == 429) {
                r.status = QUOTA;
                r.message = "Limit kuota model " + model + " habis (HTTP 429).";
            } else {
                String err = "";
                InputStream es = conn.getErrorStream();
                if (es != null) err = read(es);
                String low = err.toLowerCase();
                if (code == 401 || code == 403
                        || (code == 400 && (low.contains("api key") || low.contains("api_key")))) {
                    r.status = BAD_KEY;
                } else if (code == 400 || code == 404) {
                    r.status = SKIP;
                } else {
                    r.status = RETRY;
                }
                r.message = "HTTP " + code + (err.isEmpty() ? "" : ": " + err);
            }
        } catch (Exception e) {
            r.status = RETRY;
            r.message = String.valueOf(e);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return r;
    }

    private static void parse(String resp, String model, Result r) throws JSONException {
        JSONObject root = new JSONObject(resp);
        JSONArray cands = root.optJSONArray("candidates");
        String data = null;
        String mime = "";
        if (cands != null && cands.length() > 0) {
            JSONObject c0 = cands.optJSONObject(0);
            JSONObject content = c0 == null ? null : c0.optJSONObject("content");
            JSONArray parts = content == null ? null : content.optJSONArray("parts");
            if (parts != null) {
                for (int i = 0; i < parts.length(); i++) {
                    JSONObject p = parts.optJSONObject(i);
                    if (p == null) continue;
                    JSONObject inline = p.optJSONObject("inlineData");
                    if (inline == null) inline = p.optJSONObject("inline_data");
                    if (inline == null) continue;
                    String d = inline.optString("data", "");
                    if (d.length() > 100) {
                        data = d;
                        mime = inline.optString("mimeType", inline.optString("mime_type", ""));
                        break;
                    }
                }
            }
        }
        if (data == null) {
            JSONObject fb = root.optJSONObject("promptFeedback");
            if (fb != null && fb.has("blockReason")) {
                r.status = SKIP;
                r.message = "Permintaan diblokir: " + fb.optString("blockReason");
            } else {
                r.status = RETRY;
                r.message = "Respons audio kosong dari model " + model + ".";
            }
            return;
        }

        String lowMime = mime.toLowerCase();
        if (lowMime.contains("mpeg") || lowMime.contains("mp3") || lowMime.contains("ogg")
                || lowMime.contains("aac") || lowMime.contains("mp4") || lowMime.contains("opus")
                || lowMime.contains("webm") || lowMime.contains("flac")) {
            r.status = SKIP;
            r.message = "Model " + model + " mengirim format audio yang tidak didukung (" + mime + ").";
            return;
        }

        byte[] bytes = Base64.decode(data, Base64.DEFAULT);
        int rate = 24000;
        Matcher m = RATE.matcher(lowMime);
        if (m.find()) {
            try { rate = Integer.parseInt(m.group(1)); } catch (NumberFormatException ignored) { }
        }
        int start = 0;
        boolean riff = bytes.length > 44 && bytes[0] == 'R' && bytes[1] == 'I' && bytes[2] == 'F' && bytes[3] == 'F';
        if (riff || lowMime.contains("wav")) {
            if (bytes.length > 44) {
                start = 44;
                if (riff) {
                    int wr = (bytes[24] & 0xFF) | ((bytes[25] & 0xFF) << 8)
                            | ((bytes[26] & 0xFF) << 16) | ((bytes[27] & 0xFF) << 24);
                    if (wr >= 8000 && wr <= 96000) rate = wr;
                }
            }
        }
        int len = bytes.length - start;
        len -= len % 2;
        if (len <= 0) {
            r.status = RETRY;
            r.message = "Respons audio kosong dari model " + model + ".";
            return;
        }
        byte[] pcm = new byte[len];
        System.arraycopy(bytes, start, pcm, 0, len);
        r.pcm = pcm;
        r.sampleRate = rate;
        r.status = OK;
    }

    private static String read(InputStream in) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        char[] buf = new char[8192];
        int n;
        while ((n = br.read(buf)) != -1) sb.append(buf, 0, n);
        br.close();
        return sb.toString();
    }
}
